package com.github.hanyaeger.tutorial.entities.mobs;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.TimerContainer;
import com.github.hanyaeger.api.entities.Collider;
import com.github.hanyaeger.api.entities.SceneBorderTouchingWatcher;
import com.github.hanyaeger.api.entities.impl.DynamicSpriteEntity;
import com.github.hanyaeger.tutorial.entities.Aliens;

import java.util.Timer;

public abstract class Alien  extends DynamicSpriteEntity implements Collider, SceneBorderTouchingWatcher {
    protected int health;
    public int score;
    private boolean isShooting;
    private String sprite;
    public Alien(Coordinate2D initialLocation, boolean isShooting, String sprite) {
        super(sprite, initialLocation);
        this.isShooting = isShooting;
    }
    public void takeDamage(int damage){
        health -= damage;
    }

    public int getHealth() {
        return health;
    }

    public int getScore(){
        return score;
    }

    public void shoot(){
        if(isShooting == true){
            System.out.println("Ik schiet");
        }
    }
}
