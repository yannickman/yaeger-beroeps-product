package com.github.hanyaeger.tutorial.bullet;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.entities.Collided;
import com.github.hanyaeger.api.entities.Collider;
import com.github.hanyaeger.api.entities.SceneBorderCrossingWatcher;
import com.github.hanyaeger.api.entities.impl.DynamicSpriteEntity;
import com.github.hanyaeger.api.scenes.SceneBorder;

public class Bullet extends DynamicSpriteEntity implements SceneBorderCrossingWatcher, Collided {
    public Bullet(Coordinate2D initialLocation) {
        super("sprites/bullet.png", initialLocation);
    }

    @Override
    public void onCollision(Collider collider) {

    }

    @Override
    public void notifyBoundaryCrossing(SceneBorder sceneBorder) {

    }
}
