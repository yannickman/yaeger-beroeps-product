All Classes should be added to this package or to sub-packages of this package.

The class Empty.class only exists to prevent compilation errors while this project is
still empty. It can be safely deleted.
