package com.github.hanyaeger.tutorial.bullets;

import com.github.hanyaeger.api.AnchorPoint;
import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.Size;
import com.github.hanyaeger.api.entities.Collided;
import com.github.hanyaeger.api.entities.Collider;
import com.github.hanyaeger.api.entities.SceneBorderCrossingWatcher;
import com.github.hanyaeger.api.entities.impl.DynamicSpriteEntity;
import com.github.hanyaeger.api.scenes.SceneBorder;
import com.github.hanyaeger.tutorial.entities.Aliens;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;
import com.github.hanyaeger.tutorial.scenes.GameScene;

public abstract class Bullet extends DynamicSpriteEntity implements SceneBorderCrossingWatcher, Collider, Collided {
    protected int damage;
    private GameScene gameScene;
    private Aliens aliens;
    public Bullet(Coordinate2D initialLocation, final double direction, GameScene gameScene, Aliens aliens) {
        super("sprites/bullet.png", initialLocation, new Size(30), 1, 9);
        this.gameScene = gameScene;
        this.aliens = aliens;
        setAnchorPoint(AnchorPoint.CENTER_CENTER);
        setMotion(10, direction);
    }

    //This method takes the damage of of an alien and
    @Override
    public void onCollision(Collider collider) {
        if (collider instanceof Alien alien) {
            alien.takeDamage(this.damage);

            if(alien.getHealth() <= 0){
                gameScene.setTotalScore(alien.getScore());
                aliens.checkContents();
                alien.remove();
            }

            this.remove();
        }
    }

    @Override
    public void notifyBoundaryCrossing(SceneBorder sceneBorder) {
        remove();
    }
}
