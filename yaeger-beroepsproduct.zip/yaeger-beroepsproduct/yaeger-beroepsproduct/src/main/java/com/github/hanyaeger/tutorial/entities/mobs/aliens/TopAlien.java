package com.github.hanyaeger.tutorial.entities.mobs.aliens;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.scenes.SceneBorder;
import com.github.hanyaeger.tutorial.entities.Aliens;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;

public class TopAlien extends Alien {
    private Aliens aliens;

    public TopAlien(Coordinate2D initialLocation, Aliens aliens) {
        super(initialLocation);
        this.health = 300;
        this.score = 20;
        this.aliens = aliens;

    }

    @Override
    public void notifyBoundaryTouching(SceneBorder sceneBorder) {
        switch (sceneBorder){
            case LEFT:
                aliens.changeMotion(sceneBorder, "Right");
                break;
            case RIGHT:
                aliens.changeMotion(sceneBorder, "Left");
                break;
            case BOTTOM:
                aliens.bottomReached();
                break;
        }
    }
}
