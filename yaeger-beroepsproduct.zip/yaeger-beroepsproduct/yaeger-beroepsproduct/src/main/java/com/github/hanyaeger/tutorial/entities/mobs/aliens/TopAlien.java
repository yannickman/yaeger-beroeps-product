package com.github.hanyaeger.tutorial.entities.mobs.aliens;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.scenes.SceneBorder;
import com.github.hanyaeger.tutorial.entities.Aliens;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;
import com.github.hanyaeger.tutorial.scenes.GameScene;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class TopAlien extends Alien {
    private Aliens aliens;
    private boolean isShooting;
    private GameScene gameScene;

    public TopAlien(Coordinate2D initialLocation, Aliens aliens, boolean isShooting, GameScene gameScene) {
        super(initialLocation, false, "sprites/alien2_50.png");
        this.health = 300;
        this.score = 20;
        this.aliens = aliens;
        this.isShooting = isShooting;
        this.gameScene = gameScene;
    }

    //The aliens check which border they have touched and act accordingly.
    @Override
    public void notifyBoundaryTouching(SceneBorder sceneBorder) {
        switch (sceneBorder){
            case LEFT:
                aliens.changeMotion(sceneBorder, "Right");
                break;
            case RIGHT:
                aliens.changeMotion(sceneBorder, "Left");
                break;
            case BOTTOM:
                aliens.bottomReached();
                break;
        }
    }
}
