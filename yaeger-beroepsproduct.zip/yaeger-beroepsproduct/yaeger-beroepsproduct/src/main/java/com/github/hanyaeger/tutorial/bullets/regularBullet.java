package com.github.hanyaeger.tutorial.bullets;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.entities.Collider;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;
import com.github.hanyaeger.tutorial.scenes.GameScene;

public class regularBullet extends Bullet{
    public regularBullet(Coordinate2D initialLocation, double direction, GameScene gameScene) {
        super(initialLocation, direction, gameScene);
        damage = 100;
    }
}
