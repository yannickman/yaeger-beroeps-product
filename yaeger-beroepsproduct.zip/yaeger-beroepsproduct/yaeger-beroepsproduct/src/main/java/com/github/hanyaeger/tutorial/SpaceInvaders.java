package com.github.hanyaeger.tutorial;

import com.github.hanyaeger.api.Size;
import com.github.hanyaeger.api.YaegerGame;
import com.github.hanyaeger.tutorial.scenes.GameLostScene;
import com.github.hanyaeger.tutorial.scenes.GameScene;
import com.github.hanyaeger.tutorial.scenes.GameWonScene;
import com.github.hanyaeger.tutorial.scenes.TitleScene;

public class SpaceInvaders extends YaegerGame {

    public static void main(String[] args){
        launch(args);
    }
    public int value = 0;

    @Override
    public void setupGame() {
        setGameTitle("SpaceInvaders");
        setSize(new Size(800, 600));
    }

    //This function sets up all the scenes used in this game.
    @Override
    public void setupScenes() {
        addScene(0, new TitleScene(this, value));
        addScene(1, new GameScene(this));
        addScene(2, new GameWonScene(this));
        addScene(3, new GameLostScene(this));
    }


}
