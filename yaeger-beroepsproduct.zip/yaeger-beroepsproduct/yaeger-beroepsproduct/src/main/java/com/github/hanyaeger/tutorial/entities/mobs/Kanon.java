package com.github.hanyaeger.tutorial.entities.mobs;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.entities.Collided;
import com.github.hanyaeger.api.entities.Collider;
import com.github.hanyaeger.api.entities.SceneBorderTouchingWatcher;
import com.github.hanyaeger.api.entities.impl.DynamicSpriteEntity;
import com.github.hanyaeger.api.scenes.SceneBorder;
import com.github.hanyaeger.api.userinput.KeyListener;
import javafx.scene.input.KeyCode;

import java.util.Set;

public class Kanon extends DynamicSpriteEntity implements KeyListener, SceneBorderTouchingWatcher, Collided {
    public Kanon(Coordinate2D initialLocation) {
        super("sprites/shoot.gif", initialLocation);
    }

    @Override
    public void notifyBoundaryTouching(SceneBorder sceneBorder) {

    }

    @Override
    public void onPressedKeysChange(Set<KeyCode> pressedKeys) {
        if (pressedKeys.contains(KeyCode.LEFT)) {
            setMotion(3, 270d);
        } else if (pressedKeys.contains(KeyCode.RIGHT)) {
            setMotion(3, 90d);
        } else if (pressedKeys.contains(KeyCode.SPACE)){
//            hier komt de functie die een kogel afschiet vanaf de huidige locatie van het kanon.

            setSpeed(10);
        } else if(pressedKeys.isEmpty()){
            setSpeed(0);
        }
    }

    @Override
    public void onCollision(Collider collider) {

    }
}
