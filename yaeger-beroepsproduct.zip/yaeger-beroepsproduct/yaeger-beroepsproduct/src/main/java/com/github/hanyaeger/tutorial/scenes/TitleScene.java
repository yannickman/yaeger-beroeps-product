package com.github.hanyaeger.tutorial.scenes;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.scenes.StaticScene;
import com.github.hanyaeger.tutorial.SpaceInvaders;
import com.github.hanyaeger.tutorial.entities.buttons.TitleSceneButton;
import com.github.hanyaeger.tutorial.entities.scoretext.ScoreText;

public class TitleScene extends StaticScene {
    private SpaceInvaders spaceInvaders;

    public TitleScene(SpaceInvaders spaceInvaders){
        this.spaceInvaders = spaceInvaders;
    }

    @Override
    public void setupScene() {
        setBackgroundImage("backgrounds/ScreenshotStarfield.png");
    }

    @Override
    public void setupEntities() {
        var highScoreText = new ScoreText(new Coordinate2D(getWidth() / 2 - 85, getHeight() / 8), this.spaceInvaders, "High score");
        addEntity(highScoreText);
        var lastRoundScore = new ScoreText(new Coordinate2D(getWidth() / 6 - 40, getHeight() / 8), this.spaceInvaders, "Score");
        addEntity(lastRoundScore);
        var playButton = new TitleSceneButton(new Coordinate2D(getWidth() / 2 - 50, getHeight() / 3), this.spaceInvaders, highScoreText, lastRoundScore, "PLAY", "play");
        addEntity(playButton);
        var quitButton = new TitleSceneButton(new Coordinate2D(100, 500), this.spaceInvaders, highScoreText, lastRoundScore, "QUIT", "quit");
        addEntity(quitButton);
    }
}
