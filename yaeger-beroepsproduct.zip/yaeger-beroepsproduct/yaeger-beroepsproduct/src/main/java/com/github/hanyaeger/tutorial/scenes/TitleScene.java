package com.github.hanyaeger.tutorial.scenes;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.scenes.StaticScene;
import com.github.hanyaeger.tutorial.SpaceInvaders;
import com.github.hanyaeger.tutorial.entities.buttons.TitleSceneButton;
import com.github.hanyaeger.tutorial.entities.scoretext.ScoreText;

public class TitleScene extends StaticScene {
    private SpaceInvaders spaceInvaders;
    private int value;

    public TitleScene(SpaceInvaders spaceInvaders, int value){
        this.spaceInvaders = spaceInvaders;
        this.value = value;
    }

    @Override
    public void setupScene() {
        setBackgroundImage("backgrounds/ScreenshotStarfield.png");
    }

    //All the entities used in this scene are set up here.
    @Override
    public void setupEntities() {
        var highScoreText = new ScoreText(new Coordinate2D(getWidth() / 2 - 85, getHeight() / 8), this.spaceInvaders, "High score");
        addEntity(highScoreText);
        var highScoreAmount = new ScoreText(new Coordinate2D(getWidth() / 2 - 20, getHeight() / 8 + 30), this.spaceInvaders, String.valueOf(value));
        addEntity(highScoreAmount);

        var lastRoundScoreText = new ScoreText(new Coordinate2D(getWidth() / 6 - 40, getHeight() / 8), this.spaceInvaders, "Score");
        addEntity(lastRoundScoreText);
        var lastRoundScore = new ScoreText(new Coordinate2D(getWidth() / 6 - 10, getHeight() / 8 + 30), this.spaceInvaders, String.valueOf(value));
        addEntity(lastRoundScore);

        var playButton = new TitleSceneButton(new Coordinate2D(getWidth() / 2 - 50, getHeight() / 3), this.spaceInvaders, highScoreText, lastRoundScore, "PLAY", "play");
        addEntity(playButton);
        var quitButton = new TitleSceneButton(new Coordinate2D(100, 500), this.spaceInvaders, highScoreText, lastRoundScore, "QUIT", "quit");
        addEntity(quitButton);


    }
}
