package com.github.hanyaeger.tutorial.entities.buttons;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.entities.impl.TextEntity;
import com.github.hanyaeger.api.userinput.MouseButtonPressedListener;
import com.github.hanyaeger.api.userinput.MouseEnterListener;
import com.github.hanyaeger.api.userinput.MouseExitListener;
import com.github.hanyaeger.tutorial.SpaceInvaders;
import com.github.hanyaeger.tutorial.entities.scoretext.ScoreText;
import com.github.hanyaeger.tutorial.scenes.TitleScene;
import javafx.scene.Cursor;
import javafx.scene.input.MouseButton;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class TitleSceneButton extends TextEntity implements MouseButtonPressedListener, MouseEnterListener, MouseExitListener {
    private SpaceInvaders spaceInvaders;
    private ScoreText lastRoundScore;
    private ScoreText highScoreText;
    private String playOfQuit;

    public TitleSceneButton(Coordinate2D initialLocation, SpaceInvaders spaceInvaders, ScoreText highScoreText, ScoreText lastRoundScore, String text, String playOfQuit) {
        super(initialLocation, "PLAY");
        this.spaceInvaders = spaceInvaders;
        this.highScoreText = highScoreText;
        this.lastRoundScore = lastRoundScore;
        setText(text);
        setFill(Color.PURPLE);
        setFont(Font.font("Roboto", FontWeight.BOLD, 30));
        this.playOfQuit = playOfQuit;
    }

    public TitleSceneButton(Coordinate2D initialLocation, SpaceInvaders spaceInvaders, String text, String playOfQuit){
        super(initialLocation, "PLAY");
        this.spaceInvaders = spaceInvaders;
        setText(text);
        setFill(Color.PURPLE);
        setFont(Font.font("Roboto", FontWeight.BOLD, 30));
        this.playOfQuit = playOfQuit;
    }

    @Override
    public void onMouseButtonPressed(MouseButton mouseButton, Coordinate2D coordinate2D) {
//        spaceInvaders.setActiveScene(1);
        if(playOfQuit == "play"){
            spaceInvaders.setActiveScene(1);
        } else if(playOfQuit == "quit"){
            spaceInvaders.quit();
        } else {
            spaceInvaders.setActiveScene(0);
        }
    }

    @Override
    public void onMouseEntered() {
        setFill(Color.VIOLET);
        setCursor(Cursor.HAND);
    }

    @Override
    public void onMouseExited() {
        setFill(Color.PURPLE);
        setCursor(Cursor.DEFAULT);
    }
}
