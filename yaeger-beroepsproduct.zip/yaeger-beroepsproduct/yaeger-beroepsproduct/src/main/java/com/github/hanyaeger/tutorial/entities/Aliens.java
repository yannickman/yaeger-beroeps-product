package com.github.hanyaeger.tutorial.entities;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.entities.DynamicCompositeEntity;
import com.github.hanyaeger.api.entities.SceneBorderTouchingWatcher;
import com.github.hanyaeger.api.scenes.SceneBorder;
import com.github.hanyaeger.tutorial.SpaceInvaders;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;
import com.github.hanyaeger.tutorial.entities.mobs.aliens.MidAlien;
import com.github.hanyaeger.tutorial.entities.mobs.aliens.TopAlien;
import com.github.hanyaeger.tutorial.scenes.GameScene;

public class Aliens extends DynamicCompositeEntity implements SceneBorderTouchingWatcher {
    private Aliens aliens;
    private SpaceInvaders spaceInvaders;
    private GameScene gameScene;

    public Aliens(Coordinate2D initialLocation, SpaceInvaders spaceInvaders, GameScene gameScene) {
        super(initialLocation);
        setMotion(0.5, 90);
        this.spaceInvaders = spaceInvaders;
        this.gameScene = gameScene;
    }


    @Override
    protected void setupEntities() {
        //In this function we use 2 for loops to place all the aliens on their correct position.
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 4; j++){
                switch (j){
                    case 0:
                        addEntity(new TopAlien(new Coordinate2D(90 * i + 50, 75 * j), this, false, gameScene));
                        break;
                    case 1:
                        addEntity(new TopAlien(new Coordinate2D(90 * i + 50, 75 * j), this, false, gameScene));
                        break;
                    case 2:
                        addEntity(new MidAlien(new Coordinate2D(90 * i + 50, 75 * j), this, false, gameScene));
                        break;
                    case 3:
                        addEntity(new MidAlien(new Coordinate2D(90 * i + 50, 75 * j), this, true, gameScene));
                        break;
                }
            }
        }
    }

    //This function is used by the aliens to change the direction of movement of the Aliens boundingbox.
    //When the aliens touch the sceneborder they check wheter it is the left or the right and then call this function with the specified direction.
    public void changeMotion(SceneBorder sceneBorder, String direction) {
        this.setAnchorLocationY(this.getAnchorLocation().getY() + 5);
        if(direction == "Right"){
            setMotion(0.5, 90);
        } else {
            setMotion(0.5, 270);
        }
    }

    //When the aliens reach the bottom of the screen they call this function to end the game.
    public void bottomReached(){

        spaceInvaders.setActiveScene(3);
    }

    //This function checks if there are any aliens left in the bounding box every time an alien gets destroyed.
    public void checkContents(){
        double height = getHeight();
        double width = getWidth();
        if(height <= 50.0 && width <= 50.0){
            endGame();
        }
    }

    //This function sends the user to the game won scene when all the aliens are destroyed.
    public void endGame(){
        spaceInvaders.setActiveScene(2);
    }

    @Override
    public void notifyBoundaryTouching(SceneBorder sceneBorder) {
    }
}