package com.github.hanyaeger.tutorial.entities;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.entities.DynamicCompositeEntity;
import com.github.hanyaeger.api.entities.SceneBorderTouchingWatcher;
import com.github.hanyaeger.api.scenes.SceneBorder;
import com.github.hanyaeger.tutorial.SpaceInvaders;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;
import com.github.hanyaeger.tutorial.entities.mobs.aliens.MidAlien;
import com.github.hanyaeger.tutorial.entities.mobs.aliens.TopAlien;
import com.github.hanyaeger.tutorial.scenes.GameScene;

public class Aliens extends DynamicCompositeEntity implements SceneBorderTouchingWatcher {
    private Aliens aliens;
    private SpaceInvaders spaceInvaders;

    public Aliens(Coordinate2D initialLocation, SpaceInvaders spaceInvaders) {
        super(initialLocation);
        setMotion(0.5, 90);
        this.spaceInvaders = spaceInvaders;
    }


    @Override
    protected void setupEntities() {
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 4; j++){
                switch (j){
                    case 0:
                        addEntity(new TopAlien(new Coordinate2D(90 * i + 50, 75 * j), this));
                        break;
                    case 1:
                        addEntity(new TopAlien(new Coordinate2D(90 * i + 50, 75 * j), this));
                        break;
                    case 2:
                        addEntity(new MidAlien(new Coordinate2D(90 * i + 50, 75 * j), this));
                        break;
                    case 3:
                        addEntity(new MidAlien(new Coordinate2D(90 * i + 50, 75 * j), this));
                        break;
                }
            }
        }
    }

    public void changeMotion(SceneBorder sceneBorder, String direction) {
        System.out.println(direction);
        this.setAnchorLocationY(this.getAnchorLocation().getY() + 5);
        if(direction == "Right"){
            setMotion(0.5, 90);
        } else {
            setMotion(0.5, 270);
        }
    }

    public void bottomReached(){

        spaceInvaders.setActiveScene(3);
    }

    public void checkContents(){
        double height = getHeight();
        double width = getWidth();
        if(height <= 50.0 && width <= 50.0){
            endGame();
        }
    }

    public void endGame(){
        spaceInvaders.setActiveScene(2);
    }

    @Override
    public void notifyBoundaryTouching(SceneBorder sceneBorder) {
    }
}