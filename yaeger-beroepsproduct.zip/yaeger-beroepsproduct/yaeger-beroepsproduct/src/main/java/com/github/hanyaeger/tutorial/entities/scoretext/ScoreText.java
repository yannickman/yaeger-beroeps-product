package com.github.hanyaeger.tutorial.entities.scoretext;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.entities.impl.TextEntity;
import com.github.hanyaeger.tutorial.SpaceInvaders;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class ScoreText extends TextEntity {
    private SpaceInvaders spaceInvaders;
    private String text;

    public ScoreText(Coordinate2D initialLocation, SpaceInvaders spaceInvaders, String text) {
        super(initialLocation);
        this.spaceInvaders = spaceInvaders;
        this.text = text;
        setText(this.text);
        setFill(Color.WHITE);
        setFont(Font.font("Roboto", 30));
    }

    public void setText(){
        setText("Hallo daar");
    }
}
