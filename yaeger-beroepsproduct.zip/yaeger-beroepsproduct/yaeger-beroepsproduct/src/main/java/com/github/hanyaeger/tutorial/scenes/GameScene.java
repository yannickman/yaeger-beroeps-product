package com.github.hanyaeger.tutorial.scenes;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.entities.Direction;
import com.github.hanyaeger.api.scenes.DynamicScene;
import com.github.hanyaeger.tutorial.SpaceInvaders;
import com.github.hanyaeger.tutorial.bullets.regularBullet;
import com.github.hanyaeger.tutorial.entities.Aliens;
import com.github.hanyaeger.tutorial.entities.mobs.Kanon;
import com.github.hanyaeger.tutorial.entities.mobs.aliens.TopAlien;
import com.github.hanyaeger.tutorial.entities.scoretext.ScoreText;


public class GameScene extends DynamicScene {
    private final SpaceInvaders spaceInvaders;
    private int totalScore;
    private Aliens aliens;

    public GameScene(SpaceInvaders spaceInvaders) {
        this.spaceInvaders = spaceInvaders;
    }

    public void spawnBullet(Coordinate2D locationInScene){
        addEntity(new regularBullet(locationInScene.add(new Coordinate2D(30, 0)), Direction.UP.getValue(), this, aliens));
    }
    @Override
    public void setupScene() {
        setBackgroundImage("backgrounds/ScreenshotStarfield.png");
    }

    @Override
    public void setupEntities() {
        var kanon = new Kanon(new Coordinate2D(10, 570), this);
        addEntity(kanon);
        aliens = new Aliens(new Coordinate2D(0, 0), spaceInvaders);
        addEntity(aliens);
    }

    public void setTotalScore(int newScore){
        System.out.println(totalScore);
        totalScore += newScore;
    }

    public void setTitleSceneScore(){
    }
}