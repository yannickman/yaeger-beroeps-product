package com.github.hanyaeger.tutorial.scenes;

import com.github.hanyaeger.api.Coordinate2D;
import com.github.hanyaeger.api.scenes.DynamicScene;
import com.github.hanyaeger.tutorial.SpaceInvaders;
import com.github.hanyaeger.tutorial.bullet.Bullet;
import com.github.hanyaeger.tutorial.entities.mobs.Alien;
import com.github.hanyaeger.tutorial.entities.mobs.Kanon;

public class GameScene extends DynamicScene {
    private final SpaceInvaders spaceInvaders;

    public GameScene(SpaceInvaders spaceInvaders) {
        this.spaceInvaders = spaceInvaders;
    }

    @Override
    public void setupScene() {
        setBackgroundImage("backgrounds/ScreenshotStarfield.png");
    }

    @Override
    public void setupEntities() {
        var kanon = new Kanon(new Coordinate2D(10, 570));
        addEntity(kanon);
        int[] alienRow = new int[]{0, 1, 2, 3};
        for(int i : alienRow) {
            int height;
//            switch (i){
//                case 0:
//                    height = 10;
//                    break;
//                case 1:
//                    height = 30;
//                    break;
//                case 2:
//                    height = 50;
//                    break;
//                case 3:
//                    height = 70;
//                    break;
//            }
            if(i == 0){
                height = 10;
            } else if(i == 1){
                height = 60;
            } else if(i == 2){
                height = 110;
            } else {
                height = 160;
            }
            for (int o = 0; o < 8; o++) {
                var testAlien = new Alien(new Coordinate2D(getWidth() / 8 * o + 15, height));
                var bullet = new Bullet(new Coordinate2D(200, 200));
                addEntity(testAlien);
            }
        }
    }
}