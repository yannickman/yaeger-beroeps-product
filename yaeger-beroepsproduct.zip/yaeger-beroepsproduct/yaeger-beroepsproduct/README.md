# Yaeger tutorial: Creating Waterworld

This repository contains a tutorial in which you will create a simple game called Waterworld. We start of with an empty
project that does not contain any code. Only the assets and the project settings are provided. Step-by-step you will be
guided in the creation of simple game, and in doing so, become familiar with many of the features of Yaeger.

![Waterworld](docs/images/game/game.png)

[Dive into the tutorial](https://han-yaeger.github.io/yaeger-tutorial/)


